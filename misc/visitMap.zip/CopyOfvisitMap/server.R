source("RScript/myFun.R")
shinyServer(function(input, output, session) {
  ## Record visitor's info;
  observe({
    if (!grepl("Notodden", input$log)) {
      # print(input$log)
      msg <- gsub(".*ipInfo", paste(date(), "ipInfo"), input$log)
      if (nchar(msg) > 20) {
        write(msg, "www/visitors.txt", append  = TRUE)
      }  
    }
  })
  
  ## Reactive visitor data
  rDat <- reactive({
    DAT <- readLines("www/visitors.txt")
    DAT <- DAT[which(nchar(DAT) > 0)]
    DAT.split <- strsplit(DAT, ",|ipInfo\\|")
    Dat <- data.frame(Time = rep(NA, length(DAT.split)), IP = NA, City = NA, Lat = NA, Lon = NA)
    for ( i in 1:length(DAT.split)) { Dat[i, ] <- DAT.split[[i]]}
    Dat$Time <- as.Date(Dat$Time, "%a %b %d %H:%M:%S %Y")
    Dat$Lat <- as.numeric(Dat$Lat)
    Dat$Lon <- as.numeric(Dat$Lon)
    Dat <- unique(Dat[, c("Time", "Lon", "Lat", "IP", "City")])
    return(Dat)
  })
  
  ## Generate map;
  output$myMap <- renderMap({
    Dat <- rDat()
    Map <- Leaflet$new()
    Map$addParams(width="100%", height="800px;", layerOpts = list(maxZoom = 18, zoomControl = FALSE))
    Map$addParams(bounds = list(c(min(Dat$Lat), min(Dat$Lon)) - 10, c(max(Dat$Lat), max(Dat$Lon)) + 10))
    Points <- as.list(rep(NA, nrow(Dat)))
    for (i in 1:nrow(Dat)) {
      Points[[i]] <- c(lat = Dat$Lat[i], lon = Dat$Lon[i], 
                       value = paste(Dat$City[i], as.character(Dat$Time[i]), sep = ": "))
    }
    Map$addParams(cluster = Points)
    Map
  })
  
  ## Highcharts
  output$fig <- renderChart({
    ## Highchart basic;
    H <- Highcharts$new()
    H$addParams(dom = "fig")
    H$chart(type = "column", zoomType = "xy")
    H$legend(enabled = FALSE)
    
    # Original data;
    Dat <- rDat()
    if (nrow(Dat) > 0) {
      # Aggregate week/month;
      if (input$interval == "week") {
        Dat$Time <- d2f(Dat$Time, p = "%w")
      } else if (input$interval == "month") {
        Dat$Time <- d2f(Dat$Time, p = "%d")
      } 
      # Aggregate;
      dat <- aggregate(list(Num  = Dat$IP), list(Time = Dat$Time), length) 
      ## Cumulative;
      if (input$type == "cumu") {dat$Num <- cumsum(dat$Num)}
      ## plot time series;
      H$series(data = lapply(1:nrow(dat), FUN = function(x) {c(as.numeric(as.POSIXct(dat[x, 1])) * 1000, dat[x, 2])}),
               name = "Visitor number")
      if (input$interval == "day") {
        step <- ceiling(as.numeric(diff(as.Date(range(as.character(dat$Time)))))/10)
        H$xAxis(tickLength = 0, type = "datetime", title = "Day",
                events = list(setExtremes = setExtremes_D),
                labels = list(format = "{value:%d.%m.%Y}", step = step),
                tickInterval = 1 * 24 * 36e5)
      } else if (input$interval == "week") {
        step <- ceiling(as.numeric(diff(as.Date(range(as.character(dat$Time)))))/10/7)
        H$xAxis(tickLength = 0, type = "datetime", title = "Week",
                events = list(setExtremes = setExtremes_W),
                labels = list(format = "{value:%d.%m.%Y}", step = step),
                tickInterval = 7 * 24 * 36e5)
      } else if (input$interval == "month") {
        step <- ceiling(as.numeric(diff(as.Date(range(as.character(dat$Time)))))/10/30)
        H$xAxis(tickLength = 0, type = "datetime", title = "Month",
                events = list(setExtremes = setExtremes_M),
                labels = list(format = "{value:%d.%m.%Y}", step = step),
                tickInterval = 30 * 24 * 36e5)
      }
    } else {
      H$title(text = "No data available!")
    }
    H
  })
})  
