library(rCharts)
shinyUI(bootstrapPage(
  # Add custom CSS & Javascript;
  tagList(
    tags$head(
      tags$link(rel="stylesheet", type="text/css",href="style.css")
    ),
    tags$body(
      tags$script(src = "ipinfo.js")
    )
  ),
  
  tabsetPanel( 
    tabPanel(("Figure"), 
             showOutput("myMap", "leaflet"), 
             textInput(inputId = "log", label = "")),  
    tabPanel(("Data"),  
             div(class = "input",
                 radioButtons(inputId = "type", label = "Figure type:",
                              choices = c("Normal" = "numb", "Cumulative" = "cumu")), 
                 radioButtons(inputId = "interval", label = "Data unit",
                              choices = c("Day" = "day", "Week" = "week", "Month" = "month"))
             ), 
             div(class = "output", showOutput("fig", "highcharts"))
    ) 
  )
  
))
